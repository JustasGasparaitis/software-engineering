# Changelog for bomberman-client

## Unreleased changes
